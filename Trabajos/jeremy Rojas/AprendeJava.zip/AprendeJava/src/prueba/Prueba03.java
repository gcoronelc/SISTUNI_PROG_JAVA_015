/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prueba;

import model.Clase1;
import model.Clase2;
import model.Clase4;
import model.Clase5;

/**
 *
 * @author Alumno
 */
public class Prueba03 {
    public static void main(String[] args){
        
        Clase1 bean=new Clase2();
        System.out.println("8+6 = "+ bean.sumar(8,6));
        
        
        Clase2 obj=(Clase2) bean;
        
        System.out.println("8+6 = "+ obj.sumar(8,6));
        System.out.println("8*6 = "+ obj.multiplicar(8,6));
        
        if(bean instanceof Clase4){
            Clase4 clase4=(Clase4) bean;
            System.out.println("Si hay compatibilidad");
        }
        else{
            System.out.println("No hay compatibilidad entre dean y Clase4");
        }
        
        
    }
}
