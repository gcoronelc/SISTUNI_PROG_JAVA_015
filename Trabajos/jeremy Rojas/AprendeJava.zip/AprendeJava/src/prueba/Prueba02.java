/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prueba;

import model.Clase5;

/**
 *
 * @author Alumno
 */
public class Prueba02 {
    public static void main(String[] args){
        
        Clase5 bean=new Clase5();
        System.out.println("8+6= "+ bean.sumar(8,6));
        
    }
}
