/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg1clase3.service;

/**
 *
 * @author Alumno
 */
public final class MyMath {  // final : poque todos sus metodos van a ser de clase

    public MyMath() {
    }

    public static long factorial(int n) {
        long f = 1;
        while (n > 1) {
            f *= n--;
        }
        return f;
    }

    public static int mcd(int n1, int n2) {

        return 0;
    }

    public static int mcm(int n1, int n2) {

        return 0;
    }

    public static int[] fibonacci(int n) {

        return null;
    }

    public static boolean esPrimo(int n) {

        return false;
    }

}
