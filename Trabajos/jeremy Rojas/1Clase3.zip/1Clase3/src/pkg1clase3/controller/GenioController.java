/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg1clase3.controller;

import pkg1clase3.service.MyMath;

/**
 *
 * @author Alumno
 */
public class GenioController {
    public long factorial(int num){
        return MyMath.factorial(num);
    }
}
